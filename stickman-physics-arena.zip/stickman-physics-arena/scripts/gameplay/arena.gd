extends Node2D
class_name Arena
## Arena de combate. Solo: jugador vs IA. LAN: el anfitrión simula todo (autoritativo);
## el cliente envía su entrada y recibe snapshots (~20/s) que interpola.

const FLOOR_Y := 620.0
const SNAP_RATE := 20.0
const INPUT_RATE := 30.0

var fighters: Array = []
var controls: TouchControls
var bars: Array = []
var banner: Label
var rematch_btn: Button

var is_mp := false
var is_host := true
var my_index := 0
var ended := false

var remote_input := Vector2.ZERO
var remote_attack := false
var remote_hop := false
var _prev_atk := false
var _prev_hop := false
var _prev_r_atk := false
var _prev_r_hop := false
var _snap_t := 0.0
var _in_t := 0.0
var _ai_cd := 1.0


func _ready() -> void:
    is_mp = Net.in_match
    is_host = (not is_mp) or multiplayer.is_server()
    my_index = 0 if is_host else 1
    _build_world()
    _spawn_fighters()
    _build_hud()
    if is_mp:
        Net.peer_left.connect(_on_peer_left)


# --- Construcción -----------------------------------------------------------

func _static_rect(center: Vector2, size: Vector2, color: Color) -> void:
    var sb := StaticBody2D.new()
    sb.position = center
    sb.collision_layer = 1
    sb.collision_mask = 0
    var cs := CollisionShape2D.new()
    var r := RectangleShape2D.new()
    r.size = size
    cs.shape = r
    sb.add_child(cs)
    var v := ColorRect.new()
    v.color = color
    v.size = size
    v.position = -size * 0.5
    sb.add_child(v)
    add_child(sb)


func _crate(pos: Vector2) -> void:
    var rb := RigidBody2D.new()
    rb.position = pos
    rb.mass = 2.0
    rb.collision_layer = 1
    rb.collision_mask = 3
    var cs := CollisionShape2D.new()
    var r := RectangleShape2D.new()
    r.size = Vector2(44, 44)
    cs.shape = r
    rb.add_child(cs)
    var v := ColorRect.new()
    v.color = Color("#C98B3C")
    v.size = Vector2(44, 44)
    v.position = Vector2(-22, -22)
    rb.add_child(v)
    add_child(rb)


func _build_world() -> void:
    var bg_layer := CanvasLayer.new()
    bg_layer.layer = -10
    bg_layer.add_child(UIKit.gradient_bg())
    add_child(bg_layer)
    # Suelo con bordes abiertos: caer fuera elimina.
    _static_rect(Vector2(640, FLOOR_Y + 40), Vector2(980, 80), Color("#0B2F5E"))
    _static_rect(Vector2(400, 470), Vector2(200, 16), Color("#1E5AA8"))
    _static_rect(Vector2(880, 470), Vector2(200, 16), Color("#1E5AA8"))
    if not is_mp:
        _crate(Vector2(640, 300))
        _crate(Vector2(690, 250))


func _spawn_fighters() -> void:
    var colors := [Color("#35A0F0"), Color("#E5535C")]
    var spawns := [Vector2(420, FLOOR_Y - 135), Vector2(860, FLOOR_Y - 135)]
    for i in 2:
        var f := Fighter.new()
        add_child(f)
        f.build(spawns[i], colors[i])
        f.died.connect(_on_died)
        fighters.append(f)
    fighters[1].facing = -1.0
    if is_mp and not is_host:
        for f in fighters:
            f.set_puppet()


func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)

    for i in 2:
        var pb := ProgressBar.new()
        pb.max_value = 100.0
        pb.value = 100.0
        pb.show_percentage = false
        pb.custom_minimum_size = Vector2(0, 26)
        pb.add_theme_stylebox_override("fill", UIKit.make_style(Color("#35A0F0") if i == 0 else Color("#E5535C")))
        if i == 0:
            pb.anchor_left = 0.0
            pb.anchor_right = 0.0
            pb.offset_left = 20
            pb.offset_right = 360
        else:
            pb.anchor_left = 1.0
            pb.anchor_right = 1.0
            pb.offset_left = -360
            pb.offset_right = -20
        pb.offset_top = 18
        pb.offset_bottom = 44
        root.add_child(pb)
        bars.append(pb)

    var exit_btn := UIKit.button("SALIR", UIKit.NAVY, 40.0)
    exit_btn.anchor_left = 0.5
    exit_btn.anchor_right = 0.5
    exit_btn.offset_left = -60
    exit_btn.offset_right = 60
    exit_btn.offset_top = 14
    exit_btn.offset_bottom = 54
    exit_btn.pressed.connect(_exit_to_menu)
    root.add_child(exit_btn)

    banner = UIKit.label("", 54)
    banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    banner.offset_left = -400
    banner.offset_right = 400
    banner.offset_top = -80
    banner.offset_bottom = 0
    banner.visible = false
    root.add_child(banner)

    rematch_btn = UIKit.button("REVANCHA", UIKit.GREEN)
    rematch_btn.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    rematch_btn.offset_left = -110
    rematch_btn.offset_right = 110
    rematch_btn.offset_top = 10
    rematch_btn.offset_bottom = 64
    rematch_btn.visible = false
    rematch_btn.pressed.connect(func() -> void: get_tree().reload_current_scene())
    root.add_child(rematch_btn)

    controls = TouchControls.new()
    layer.add_child(controls)


# --- Bucle ------------------------------------------------------------------

func _physics_process(delta: float) -> void:
    if ended:
        return
    if is_mp and not is_host:
        _client_tick(delta)
    else:
        _host_tick(delta)


func _host_tick(delta: float) -> void:
    var f0: Fighter = fighters[0]
    var f1: Fighter = fighters[1]
    f0.move_input = controls.move
    if controls.attack and not _prev_atk:
        f0.request_attack()
    if controls.hop and not _prev_hop:
        f0.request_hop()
    _prev_atk = controls.attack
    _prev_hop = controls.hop

    if is_mp:
        f1.move_input = remote_input
        if remote_attack and not _prev_r_atk:
            f1.request_attack()
        if remote_hop and not _prev_r_hop:
            f1.request_hop()
        _prev_r_atk = remote_attack
        _prev_r_hop = remote_hop
    else:
        _ai(f1, f0, delta)

    if f0.swing_pending:
        f0.swing_pending = false
        _resolve_hit(f0, f1)
    if f1.swing_pending:
        f1.swing_pending = false
        _resolve_hit(f1, f0)

    if is_mp:
        _snap_t -= delta
        if _snap_t <= 0.0:
            _snap_t = 1.0 / SNAP_RATE
            h2c_snapshot.rpc((fighters[0] as Fighter).snapshot(), (fighters[1] as Fighter).snapshot())


func _client_tick(delta: float) -> void:
    _in_t -= delta
    if _in_t <= 0.0:
        _in_t = 1.0 / INPUT_RATE
        c2h_input.rpc_id(1, controls.move, controls.attack, controls.hop)


func _process(_delta: float) -> void:
    for i in bars.size():
        (bars[i] as ProgressBar).value = (fighters[i] as Fighter).health


func _ai(f: Fighter, target: Fighter, delta: float) -> void:
    var dx := target.torso_pos().x - f.torso_pos().x
    f.move_input = Vector2(clampf(dx / 40.0, -1.0, 1.0) if absf(dx) > 85.0 else 0.0, 0.0)
    _ai_cd -= delta
    if absf(dx) < 100.0 and _ai_cd <= 0.0:
        f.request_attack()
        _ai_cd = randf_range(0.9, 1.7)


func _resolve_hit(att: Fighter, vic: Fighter) -> void:
    var ap: RigidBody2D = att.parts["pelvis"]
    var vp: RigidBody2D = vic.parts["pelvis"]
    var dx := vp.global_position.x - ap.global_position.x
    if absf(dx) > 110.0 or absf(vp.global_position.y - ap.global_position.y) > 90.0:
        return
    if absf(dx) > 20.0 and signf(dx) != att.facing:
        return
    var hand: Vector2 = (att.parts["larm_r"] as RigidBody2D).global_position + Vector2(att.facing * 30.0, 0.0)
    var best := "torso"
    var bd := 1e9
    for n in Fighter.PART_ORDER:
        var d := hand.distance_to((vic.parts[n] as RigidBody2D).global_position)
        if d < bd:
            bd = d
            best = n
    var dmg := 8.0
    if best == "head":
        dmg = 14.0
    elif best.begins_with("thigh") or best.begins_with("shin"):
        dmg = 5.0
    vic.take_hit(Vector2(att.facing, -0.25).normalized(), 520.0, dmg, best)


func _on_died(f: Fighter) -> void:
    if ended or (is_mp and not is_host):
        return
    var winner := 1 if f == fighters[0] else 0
    _show_end(winner)
    if is_mp:
        h2c_end.rpc(winner)


func _show_end(winner: int) -> void:
    ended = true
    banner.text = "¡GANA EL JUGADOR %d!" % (winner + 1)
    banner.visible = true
    rematch_btn.visible = not is_mp


func _on_peer_left() -> void:
    ended = true
    banner.text = "Rival desconectado"
    banner.visible = true


func _exit_to_menu() -> void:
    Net.leave()
    get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")


# --- RPC --------------------------------------------------------------------

@rpc("any_peer", "call_remote", "unreliable_ordered")
func c2h_input(move: Vector2, atk: bool, hop: bool) -> void:
    if not multiplayer.is_server():
        return
    # Validación: el cliente solo aporta su entrada, nunca daño ni resultados.
    remote_input = move.limit_length(1.0)
    remote_attack = atk
    remote_hop = hop


@rpc("authority", "call_remote", "unreliable_ordered")
func h2c_snapshot(a: PackedFloat32Array, b: PackedFloat32Array) -> void:
    if fighters.size() < 2:
        return
    (fighters[0] as Fighter).apply_snapshot(a)
    (fighters[1] as Fighter).apply_snapshot(b)


@rpc("authority", "call_remote", "reliable")
func h2c_end(winner: int) -> void:
    _show_end(clampi(winner, 0, 1))
