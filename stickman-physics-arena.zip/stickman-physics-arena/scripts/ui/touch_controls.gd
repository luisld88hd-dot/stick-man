extends Control
class_name TouchControls
## Joystick virtual (mitad izquierda) + botones GOLPE y SALTO. Multitáctil.

const STICK_RADIUS := 90.0

var move := Vector2.ZERO
var attack := false
var hop := false

var _stick_id := -1
var _center := Vector2.ZERO
var _knob := Vector2.ZERO
var _attack_id := -1
var _hop_id := -1


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _attack_center() -> Vector2:
    var s := get_viewport_rect().size
    return Vector2(s.x - 110.0, s.y - 110.0)


func _hop_center() -> Vector2:
    var s := get_viewport_rect().size
    return Vector2(s.x - 250.0, s.y - 80.0)


func _input(event: InputEvent) -> void:
    var s := get_viewport_rect().size
    if event is InputEventScreenTouch:
        var e := event as InputEventScreenTouch
        if e.pressed:
            if e.position.distance_to(_attack_center()) < 70.0 and _attack_id == -1:
                _attack_id = e.index
                attack = true
            elif e.position.distance_to(_hop_center()) < 56.0 and _hop_id == -1:
                _hop_id = e.index
                hop = true
            elif e.position.x < s.x * 0.5 and e.position.y > s.y * 0.25 and _stick_id == -1:
                _stick_id = e.index
                _center = e.position
                _knob = e.position
                move = Vector2.ZERO
        else:
            if e.index == _stick_id:
                _stick_id = -1
                move = Vector2.ZERO
            elif e.index == _attack_id:
                _attack_id = -1
                attack = false
            elif e.index == _hop_id:
                _hop_id = -1
                hop = false
        queue_redraw()
    elif event is InputEventScreenDrag:
        var d := event as InputEventScreenDrag
        if d.index == _stick_id:
            var off := (d.position - _center).limit_length(STICK_RADIUS)
            _knob = _center + off
            move = off / STICK_RADIUS
            queue_redraw()


func _draw() -> void:
    if _stick_id != -1:
        draw_circle(_center, STICK_RADIUS, Color(1, 1, 1, 0.14))
        draw_arc(_center, STICK_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 3.0, true)
        draw_circle(_knob, 36.0, Color(1, 1, 1, 0.55))
    var font := ThemeDB.fallback_font
    draw_circle(_attack_center(), 62.0, Color(0.85, 0.3, 0.33, 0.85 if attack else 0.6))
    draw_string(font, _attack_center() + Vector2(-30, 7), "GOLPE", HORIZONTAL_ALIGNMENT_CENTER, 60, 18, Color.WHITE)
    draw_circle(_hop_center(), 48.0, Color(0.21, 0.74, 0.33, 0.85 if hop else 0.6))
    draw_string(font, _hop_center() + Vector2(-30, 7), "SALTO", HORIZONTAL_ALIGNMENT_CENTER, 60, 16, Color.WHITE)
