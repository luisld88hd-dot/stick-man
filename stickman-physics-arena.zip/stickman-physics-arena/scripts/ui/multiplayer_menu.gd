extends Control
class_name MultiplayerMenu

var _status: Label
var _ip_edit: LineEdit
var _port_edit: LineEdit
var _found_box: VBoxContainer
var _start_btn: Button


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(UIKit.gradient_bg())

    var scroll := ScrollContainer.new()
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.offset_left = 120
    scroll.offset_right = -120
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    add_child(scroll)

    var stack := VBoxContainer.new()
    stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    stack.add_theme_constant_override("separation", 8)
    scroll.add_child(stack)

    stack.add_child(UIKit.label("MULTIJUGADOR", 32))
    var info := UIKit.label("Se juega por Wi-Fi local. No se necesita Internet.", 14, Color("#D7E9FF"))
    stack.add_child(info)

    var create := UIKit.button("CREAR PARTIDA", UIKit.GREEN)
    create.pressed.connect(_on_create)
    stack.add_child(create)

    var search := UIKit.button("BUSCAR PARTIDAS LOCALES", UIKit.BLUE)
    search.pressed.connect(_on_search)
    stack.add_child(search)

    _found_box = VBoxContainer.new()
    _found_box.add_theme_constant_override("separation", 6)
    stack.add_child(_found_box)

    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    stack.add_child(row)
    _ip_edit = LineEdit.new()
    _ip_edit.placeholder_text = "IP del anfitrión (ej. 192.168.43.1)"
    _ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _ip_edit.custom_minimum_size = Vector2(0, 48)
    row.add_child(_ip_edit)
    _port_edit = LineEdit.new()
    _port_edit.text = str(Net.DEFAULT_PORT)
    _port_edit.custom_minimum_size = Vector2(110, 48)
    row.add_child(_port_edit)

    var join := UIKit.button("CONECTAR POR IP", UIKit.PURPLE)
    join.pressed.connect(_on_join_ip)
    stack.add_child(join)

    _start_btn = UIKit.button("INICIAR PARTIDA", UIKit.ORANGE)
    _start_btn.visible = false
    _start_btn.pressed.connect(func() -> void: Net.start_match.rpc())
    stack.add_child(_start_btn)

    _status = UIKit.label("", 15, Color("#FFE9A8"))
    _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    stack.add_child(_status)

    var back := UIKit.button("VOLVER", UIKit.NAVY)
    back.pressed.connect(_on_back)
    stack.add_child(back)

    Net.status_changed.connect(func(t: String) -> void: _status.text = t)
    Net.peer_joined.connect(_on_peer_joined)
    Net.game_found.connect(_on_game_found)


func _port() -> int:
    var p := int(_port_edit.text)
    return p if p > 1023 and p < 65536 else Net.DEFAULT_PORT


func _on_create() -> void:
    if Net.host_game(_port()) == OK:
        var ips := Net.local_ips()
        var ip_txt := ", ".join(ips) if ips.size() > 0 else "(sin IP: conecta el Wi-Fi o activa el punto de acceso)"
        _status.text = "Sala creada. IP: %s · Puerto: %d\nEl otro teléfono debe estar en la misma red." % [ip_txt, Net.port]


func _on_search() -> void:
    for c in _found_box.get_children():
        c.queue_free()
    if Net.start_listen() == OK:
        _status.text = "Buscando partidas… (si no aparece nada, usa CONECTAR POR IP)"


func _on_game_found(ip: String, port: int) -> void:
    var b := UIKit.button("Unirse a %s:%d" % [ip, port], UIKit.GREEN, 44.0)
    b.pressed.connect(func() -> void: Net.join_game(ip, port))
    _found_box.add_child(b)


func _on_join_ip() -> void:
    Net.join_game(_ip_edit.text.strip_edges(), _port())


func _on_peer_joined() -> void:
    _start_btn.visible = Net.is_host
    if Net.is_host:
        _status.text = "¡Jugador conectado! Pulsa INICIAR PARTIDA."


func _on_back() -> void:
    Net.leave()
    get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
