extends RefCounted
class_name UIKit
## Utilidades de interfaz compartidas (tema común de todas las pantallas).

const BLUE := Color("#168BE0")
const GREEN := Color("#36BD55")
const PURPLE := Color("#8754D8")
const ORANGE := Color("#ED9638")
const RED := Color("#D94C55")
const NAVY := Color("#092F68")


static func gradient_bg() -> TextureRect:
    var gradient := Gradient.new()
    gradient.colors = PackedColorArray([Color("#147BC4"), Color("#073A7A")])
    var tex := GradientTexture2D.new()
    tex.gradient = gradient
    tex.fill_from = Vector2(0, 0)
    tex.fill_to = Vector2(0, 1)
    var bg := TextureRect.new()
    bg.texture = tex
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return bg


static func make_style(color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.set_corner_radius_all(13)
    style.content_margin_left = 16
    style.content_margin_right = 16
    style.content_margin_top = 9
    style.content_margin_bottom = 9
    style.shadow_size = 5
    style.shadow_color = Color(0, 0, 0, 0.28)
    style.shadow_offset = Vector2(0, 4)
    return style


static func button(caption: String, color: Color, min_height: float = 54.0) -> Button:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(0, min_height)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.add_theme_font_size_override("font_size", 19)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", make_style(color))
    b.add_theme_stylebox_override("hover", make_style(color.lightened(0.12)))
    b.add_theme_stylebox_override("pressed", make_style(color.darkened(0.15)))
    b.add_theme_stylebox_override("focus", make_style(color.lightened(0.18)))
    b.add_theme_stylebox_override("disabled", make_style(color.darkened(0.4)))
    # Animación breve al pulsar.
    b.resized.connect(func() -> void: b.pivot_offset = b.size * 0.5)
    b.button_down.connect(func() -> void:
        var t := b.create_tween()
        t.tween_property(b, "scale", Vector2(0.95, 0.95), 0.06))
    b.button_up.connect(func() -> void:
        var t := b.create_tween()
        t.tween_property(b, "scale", Vector2.ONE, 0.08))
    return b


static func label(text: String, size: int = 16, color: Color = Color.WHITE) -> Label:
    var l := Label.new()
    l.text = text
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    return l
