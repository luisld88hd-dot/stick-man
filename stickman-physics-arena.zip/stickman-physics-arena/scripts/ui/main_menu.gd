extends Control
class_name MainMenu

signal menu_action(action: String)

const VERSION := "v0.1.0"

var _toast: Label


class StickmanDecoration extends Control:
    var tint: Color = Color("#092F68")

    func _draw() -> void:
        var c := tint
        var center := size * 0.5
        draw_circle(center + Vector2(0, -65), 17, c)
        draw_line(center + Vector2(0, -47), center + Vector2(0, 12), c, 12.0, true)
        draw_line(center + Vector2(0, -30), center + Vector2(-42, -2), c, 10.0, true)
        draw_line(center + Vector2(0, -30), center + Vector2(40, -53), c, 10.0, true)
        draw_line(center + Vector2(0, 12), center + Vector2(-29, 65), c, 11.0, true)
        draw_line(center + Vector2(0, 12), center + Vector2(31, 60), c, 11.0, true)


func _ready() -> void:
    _build_interface()
    menu_action.connect(_on_menu_action)


func _build_interface() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(UIKit.gradient_bg())

    var left := StickmanDecoration.new()
    left.anchor_top = 0.5
    left.anchor_bottom = 0.5
    left.offset_left = 20
    left.offset_right = 160
    left.offset_top = -145
    left.offset_bottom = 145
    left.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(left)

    var right := StickmanDecoration.new()
    right.anchor_left = 1.0
    right.anchor_right = 1.0
    right.anchor_top = 0.5
    right.anchor_bottom = 0.5
    right.offset_left = -160
    right.offset_right = -20
    right.offset_top = -145
    right.offset_bottom = 145
    right.pivot_offset = Vector2(70, 145)
    right.scale.x = -1
    right.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(right)

    var scroll := ScrollContainer.new()
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.offset_left = 180
    scroll.offset_right = -180
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    add_child(scroll)

    var stack := VBoxContainer.new()
    stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    stack.add_theme_constant_override("separation", 9)
    scroll.add_child(stack)

    var title := UIKit.label("STICKMAN\nPHYSICS ARENA", 34)
    stack.add_child(title)
    stack.add_child(UIKit.label("FÍSICA · COMBATE · ARENAS", 12, Color("#D7E9FF")))

    _add_button(stack, "JUGAR SOLO", UIKit.BLUE, "solo")
    _add_button(stack, "MULTIJUGADOR", UIKit.GREEN, "multiplayer")
    _add_button(stack, "PERSONALIZACIÓN", UIKit.PURPLE, "customization")
    _add_button(stack, "ARMAS Y ARSENAL", UIKit.ORANGE, "arsenal")
    _add_button(stack, "ARENAS / EDITOR", UIKit.RED, "arena_editor")
    _add_button(stack, "CONFIGURACIÓN", UIKit.NAVY, "settings")

    var ver := UIKit.label(VERSION, 12, Color("#D7E9FF"))
    ver.anchor_left = 1.0
    ver.anchor_right = 1.0
    ver.anchor_top = 1.0
    ver.anchor_bottom = 1.0
    ver.offset_left = -90
    ver.offset_top = -28
    ver.offset_right = -10
    ver.offset_bottom = -6
    add_child(ver)

    _toast = UIKit.label("", 18)
    _toast.anchor_left = 0.0
    _toast.anchor_right = 1.0
    _toast.anchor_top = 1.0
    _toast.anchor_bottom = 1.0
    _toast.offset_top = -52
    _toast.offset_bottom = -12
    _toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_toast)


func _add_button(parent: VBoxContainer, caption: String, color: Color, action_id: String) -> void:
    var b := UIKit.button(caption, color)
    b.pressed.connect(func() -> void: menu_action.emit(action_id))
    parent.add_child(b)


func _on_menu_action(action: String) -> void:
    match action:
        "solo":
            Net.in_match = false
            get_tree().change_scene_to_file("res://scenes/arenas/arena.tscn")
        "multiplayer":
            get_tree().change_scene_to_file("res://scenes/ui/multiplayer_menu.tscn")
        _:
            _show_toast("Esta pantalla aún no está implementada en esta versión.")


func _show_toast(text: String) -> void:
    _toast.text = text
    _toast.modulate.a = 1.0
    var t := create_tween()
    t.tween_interval(1.8)
    t.tween_property(_toast, "modulate:a", 0.0, 0.5)
