extends Node
## Red LAN: ENet (UDP) con anfitrión autoritativo + descubrimiento por broadcast UDP.

signal status_changed(text: String)
signal peer_joined
signal peer_left
signal connected_to_host
signal connection_failed_sig
signal game_found(ip: String, port: int)

const DEFAULT_PORT := 7777
const DISCOVERY_PORT := 47777
const MAGIC := "SPA1"

var in_match := false
var is_host := false
var port := DEFAULT_PORT

var _bcast: PacketPeerUDP
var _listen: PacketPeerUDP
var _bcast_t := 0.0
var _known := {}


func _ready() -> void:
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_ok)
    multiplayer.connection_failed.connect(_on_connected_fail)
    multiplayer.server_disconnected.connect(_on_server_gone)


func local_ips() -> PackedStringArray:
    var out := PackedStringArray()
    for a in IP.get_local_addresses():
        if ":" in a or a.begins_with("127.") or a.begins_with("169.254."):
            continue
        out.append(a)
    return out


func host_game(p: int = DEFAULT_PORT) -> Error:
    leave()
    port = p
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(p, 1)
    if err != OK:
        status_changed.emit("No se pudo crear la sala (error %d). ¿Puerto %d en uso?" % [err, p])
        return err
    multiplayer.multiplayer_peer = peer
    is_host = true
    _start_broadcast()
    status_changed.emit("Sala creada. Esperando al segundo jugador…")
    return OK


func join_game(ip: String, p: int = DEFAULT_PORT) -> Error:
    leave()
    if not ip.is_valid_ip_address():
        status_changed.emit("La dirección IP no es válida.")
        return ERR_INVALID_PARAMETER
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(ip, p)
    if err != OK:
        status_changed.emit("No se pudo iniciar la conexión (error %d)." % err)
        return err
    multiplayer.multiplayer_peer = peer
    is_host = false
    status_changed.emit("Conectando a %s:%d …" % [ip, p])
    return OK


func leave() -> void:
    stop_broadcast()
    stop_listen()
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    in_match = false
    is_host = false


# --- Descubrimiento ---------------------------------------------------------

func _start_broadcast() -> void:
    _bcast = PacketPeerUDP.new()
    _bcast.set_broadcast_enabled(true)
    _bcast.set_dest_address("255.255.255.255", DISCOVERY_PORT)


func stop_broadcast() -> void:
    if _bcast != null:
        _bcast.close()
        _bcast = null


func start_listen() -> Error:
    stop_listen()
    _known.clear()
    _listen = PacketPeerUDP.new()
    var err := _listen.bind(DISCOVERY_PORT)
    if err != OK:
        _listen = null
        status_changed.emit("No se pudo abrir la búsqueda (error %d). Usa CONECTAR POR IP." % err)
    return err


func stop_listen() -> void:
    if _listen != null:
        _listen.close()
        _listen = null


func _process(delta: float) -> void:
    if _bcast != null:
        _bcast_t -= delta
        if _bcast_t <= 0.0:
            _bcast_t = 1.0
            _bcast.put_packet(("%s|%d" % [MAGIC, port]).to_utf8_buffer())
    if _listen != null:
        while _listen.get_available_packet_count() > 0:
            var txt := _listen.get_packet().get_string_from_utf8()
            var ip := _listen.get_packet_ip()
            var parts := txt.split("|")
            if parts.size() == 2 and parts[0] == MAGIC and parts[1].is_valid_int():
                var key := "%s:%s" % [ip, parts[1]]
                if not _known.has(key):
                    _known[key] = true
                    game_found.emit(ip, int(parts[1]))


# --- Eventos ----------------------------------------------------------------

func _on_peer_connected(_id: int) -> void:
    if is_host:
        stop_broadcast()
        status_changed.emit("¡Jugador conectado!")
    peer_joined.emit()


func _on_peer_disconnected(_id: int) -> void:
    status_changed.emit("El rival se desconectó.")
    peer_left.emit()


func _on_connected_ok() -> void:
    status_changed.emit("Conectado. Esperando a que el anfitrión inicie…")
    connected_to_host.emit()


func _on_connected_fail() -> void:
    status_changed.emit("No se pudo conectar. Comprueba la IP y que ambos teléfonos estén en la misma red Wi-Fi (algunos hotspots aíslan los dispositivos; prueba otra red).")
    connection_failed_sig.emit()


func _on_server_gone() -> void:
    status_changed.emit("El anfitrión cerró la sala.")
    peer_left.emit()


@rpc("authority", "call_local", "reliable")
func start_match() -> void:
    in_match = true
    get_tree().change_scene_to_file("res://scenes/arenas/arena.tscn")
