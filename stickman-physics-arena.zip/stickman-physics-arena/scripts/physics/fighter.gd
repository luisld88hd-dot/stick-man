extends Node2D
class_name Fighter
## Stickman con ragdoll de 11 RigidBody2D unidos por PinJoint2D.
## Control activo por torques PD + muelle de soporte; habilidades de joystick (2 s).

const PART_ORDER := ["head", "torso", "pelvis", "uarm_l", "larm_l", "uarm_r", "larm_r",
    "thigh_l", "shin_l", "thigh_r", "shin_r"]

# nombre: [centro, largo, radio, masa]  (largo 0 => círculo)
const SPEC := {
    "head": [Vector2(0, -80), 0.0, 12.0, 1.5],
    "torso": [Vector2(0, -48), 28.0, 7.0, 4.0],
    "pelvis": [Vector2(0, -24), 4.0, 7.0, 3.0],
    "uarm_l": [Vector2(-10, -48), 14.0, 4.0, 0.8],
    "larm_l": [Vector2(-10, -34), 14.0, 4.0, 0.6],
    "uarm_r": [Vector2(10, -48), 14.0, 4.0, 0.8],
    "larm_r": [Vector2(10, -34), 14.0, 4.0, 0.6],
    "thigh_l": [Vector2(-5, -14), 20.0, 5.0, 1.5],
    "shin_l": [Vector2(-5, 6), 20.0, 5.0, 1.2],
    "thigh_r": [Vector2(5, -14), 20.0, 5.0, 1.5],
    "shin_r": [Vector2(5, 6), 20.0, 5.0, 1.2],
}

# [hijo, padre, ancla]
const JOINTS := [
    ["head", "torso", Vector2(0, -66)],
    ["torso", "pelvis", Vector2(0, -28)],
    ["uarm_l", "torso", Vector2(-10, -56)],
    ["larm_l", "uarm_l", Vector2(-10, -41)],
    ["uarm_r", "torso", Vector2(10, -56)],
    ["larm_r", "uarm_r", Vector2(10, -41)],
    ["thigh_l", "pelvis", Vector2(-5, -24)],
    ["shin_l", "thigh_l", Vector2(-5, -4)],
    ["thigh_r", "pelvis", Vector2(5, -24)],
    ["shin_r", "thigh_r", Vector2(5, -4)],
]

# Ajustes de equilibrio y habilidades (configurables)
const HOVER_HEIGHT := 46.0
const HOVER_K := 3300.0
const HOVER_D := 500.0
const MOVE_ACCEL := 1100.0
const MAX_SPEED := 260.0
const DEADZONE := 0.6
const JUMP_CHARGE_TIME := 2.0
const SHIELD_CHARGE_TIME := 2.0
const SHIELD_DURATION := 3.0
const SHIELD_COOLDOWN := 5.0
const JUMP_SPEED := 700.0
const SMALL_JUMP_SPEED := 380.0

signal died(fighter: Fighter)

var body_color := Color("#168BE0")
var parts := {}
var joints: Array = []
var total_mass := 0.0

var move_input := Vector2.ZERO
var facing := 1.0
var health := 100.0
var stun := 0.0
var attack_cd := 0.0
var swing := 0.0
var swing_pending := false

var jump_charge := 0.0
var shield_charge := 0.0
var shield_time_left := 0.0
var shield_cooldown := 0.0
var _jump_latch := false
var _shield_latch := false

var is_puppet := false
var _targets := PackedFloat32Array()
var _t := 0.0


class PartVisual extends Node2D:
    var length := 0.0
    var radius := 5.0
    var color := Color.WHITE

    func _draw() -> void:
        if length <= 0.0:
            draw_circle(Vector2.ZERO, radius, color)
        else:
            draw_line(Vector2(0, -length * 0.5), Vector2(0, length * 0.5), color, radius * 2.0, true)
            draw_circle(Vector2(0, -length * 0.5), radius, color)
            draw_circle(Vector2(0, length * 0.5), radius, color)


func build(spawn: Vector2, color: Color) -> void:
    body_color = color
    for n in PART_ORDER:
        var s: Array = SPEC[n]
        var rb := RigidBody2D.new()
        rb.name = n
        rb.mass = s[3]
        rb.linear_damp = 0.4
        rb.angular_damp = 2.0
        rb.can_sleep = false
        rb.collision_layer = 2
        rb.collision_mask = 3
        var pm := PhysicsMaterial.new()
        pm.friction = 0.9
        pm.bounce = 0.0
        rb.physics_material_override = pm
        var cs := CollisionShape2D.new()
        if s[1] <= 0.0:
            var c := CircleShape2D.new()
            c.radius = s[2]
            cs.shape = c
        else:
            var cap := CapsuleShape2D.new()
            cap.radius = s[2]
            cap.height = float(s[1]) + 2.0 * float(s[2])
            cs.shape = cap
        rb.add_child(cs)
        var vis := PartVisual.new()
        vis.length = s[1]
        vis.radius = s[2]
        vis.color = color if n != "head" else color.lightened(0.15)
        rb.add_child(vis)
        add_child(rb)
        rb.global_position = spawn + (s[0] as Vector2)
        parts[n] = rb
        total_mass += rb.mass
    for a in parts.values():
        for b in parts.values():
            if a != b:
                a.add_collision_exception_with(b)
    for j in JOINTS:
        var pin := PinJoint2D.new()
        add_child(pin)
        pin.global_position = spawn + (j[2] as Vector2)
        pin.node_a = (parts[j[1]] as Node).get_path()
        pin.node_b = (parts[j[0]] as Node).get_path()
        pin.softness = 0.0
        joints.append(pin)


func set_puppet() -> void:
    is_puppet = true
    for pin in joints:
        pin.queue_free()
    joints.clear()
    for n in PART_ORDER:
        var rb: RigidBody2D = parts[n]
        rb.freeze_mode = RigidBody2D.FREEZE_MODE_KINEMATIC
        rb.freeze = true


func torso_pos() -> Vector2:
    return (parts["torso"] as RigidBody2D).global_position


func request_attack() -> void:
    if attack_cd > 0.0 or stun > 0.0 or health <= 0.0:
        return
    attack_cd = 0.5
    swing = 0.25
    swing_pending = true
    var hand: RigidBody2D = parts["larm_r"]
    hand.apply_central_impulse(Vector2(facing * 500.0, -80.0) * hand.mass)


func request_hop() -> void:
    if stun > 0.0 or is_puppet or _ground_dist() < 0.0 or _ground_dist() > HOVER_HEIGHT + 14.0:
        return
    for n in PART_ORDER:
        var rb: RigidBody2D = parts[n]
        rb.apply_central_impulse(Vector2(0, -SMALL_JUMP_SPEED * rb.mass))


func take_hit(dir: Vector2, power: float, dmg: float, part_name: String) -> void:
    if health <= 0.0:
        return
    var blocked := shield_time_left > 0.0
    if blocked:
        dmg = 0.0
        power *= 0.25
    else:
        health = maxf(0.0, health - dmg)
    jump_charge = 0.0
    shield_charge = 0.0
    stun = maxf(stun, 0.25 if blocked else 0.5 + power / 2500.0)
    for n in PART_ORDER:
        var rb: RigidBody2D = parts[n]
        var mult := 0.3
        if n == "head":
            mult = 1.1
        elif n == "torso":
            mult = 1.0
        elif n == "pelvis":
            mult = 0.7
        if n == part_name:
            mult *= 1.8
        rb.apply_central_impulse(dir * power * mult * rb.mass * 0.6)
    (parts[part_name] as RigidBody2D).apply_torque_impulse(dir.x * power * 4.0)
    if health <= 0.0:
        stun = 999.0
        died.emit(self)


func _ground_dist() -> float:
    var pel: RigidBody2D = parts["pelvis"]
    var q := PhysicsRayQueryParameters2D.create(
        pel.global_position, pel.global_position + Vector2(0, 110), 1)
    var r := get_world_2d().direct_space_state.intersect_ray(q)
    if r.is_empty():
        return -1.0
    return pel.global_position.distance_to(r.position)


func _pd(rb: RigidBody2D, target: float, k: float, d: float) -> void:
    var err := wrapf(target - rb.rotation, -PI, PI)
    rb.apply_torque(err * k - rb.angular_velocity * d)


func _physics_process(delta: float) -> void:
    if is_puppet or parts.is_empty():
        return
    _t += delta
    stun = maxf(0.0, stun - delta) if stun < 900.0 else stun
    attack_cd = maxf(0.0, attack_cd - delta)
    swing = maxf(0.0, swing - delta)
    var torso: RigidBody2D = parts["torso"]
    var pel: RigidBody2D = parts["pelvis"]
    var alive := health > 0.0
    var gd := _ground_dist()
    var grounded := gd >= 0.0 and gd < HOVER_HEIGHT + 14.0

    if absf(move_input.x) > 0.3:
        facing = signf(move_input.x)

    if stun <= 0.0 and alive:
        # Postura erguida (controladores PD de torque).
        _pd(torso, 0.0, 20000.0, 3000.0)
        _pd(pel, 0.0, 12000.0, 2000.0)
        _pd(parts["head"], 0.0, 2500.0, 300.0)
        # Soporte tipo muelle: mantiene al personaje de pie sin eliminar su física.
        if grounded:
            var f := (HOVER_HEIGHT - gd) * HOVER_K - pel.linear_velocity.y * HOVER_D \
                + total_mass * 980.0 * 0.9
            pel.apply_central_force(Vector2(0, -clampf(f, 0.0, total_mass * 980.0 * 1.8)))
        # Locomoción.
        var mx := move_input.x
        if grounded and absf(mx) > 0.15:
            if absf(pel.linear_velocity.x) < MAX_SPEED or signf(pel.linear_velocity.x) != signf(mx):
                pel.apply_central_force(Vector2(mx * MOVE_ACCEL * total_mass, 0))
        elif grounded:
            pel.apply_central_force(Vector2(-pel.linear_velocity.x * total_mass * 8.0, 0))
        # Piernas: paso alternado según velocidad.
        var swing_leg := sin(_t * 11.0) * clampf(mx, -1.0, 1.0) * 0.7
        _pd(parts["thigh_l"], swing_leg, 3000.0, 300.0)
        _pd(parts["thigh_r"], -swing_leg, 3000.0, 300.0)
        _pd(parts["shin_l"], 0.0, 2000.0, 250.0)
        _pd(parts["shin_r"], 0.0, 2000.0, 250.0)
        # Brazos: reposo o golpe.
        var arm_target := 0.15 * facing
        if swing > 0.0:
            arm_target = -facing * 1.5
        _pd(parts["uarm_r"], arm_target, 800.0, 100.0)
        _pd(parts["larm_r"], arm_target * 0.7, 600.0, 80.0)
        _pd(parts["uarm_l"], -0.15 * facing, 800.0, 100.0)
        _pd(parts["larm_l"], -0.1 * facing, 600.0, 80.0)
        _update_skills(delta)
    else:
        jump_charge = 0.0
        shield_charge = 0.0
        shield_time_left = maxf(0.0, shield_time_left - delta)

    if torso.global_position.y > 950.0 and health > 0.0:
        health = 0.0
        stun = 999.0
        died.emit(self)


func _update_skills(delta: float) -> void:
    shield_cooldown = maxf(0.0, shield_cooldown - delta)
    shield_time_left = maxf(0.0, shield_time_left - delta)
    var up := move_input.y < -DEADZONE and absf(move_input.x) < 0.5
    var down := move_input.y > DEADZONE and absf(move_input.x) < 0.5
    if not up:
        _jump_latch = false
    if not down:
        _shield_latch = false

    # Salto especial: mantener arriba 2 s.
    if up and not _jump_latch:
        jump_charge += delta
        if jump_charge >= JUMP_CHARGE_TIME:
            jump_charge = 0.0
            _jump_latch = true
            for n in PART_ORDER:
                var rb: RigidBody2D = parts[n]
                rb.apply_central_impulse(Vector2(0, -JUMP_SPEED * rb.mass))
    else:
        jump_charge = 0.0

    # Escudo: mantener abajo 2 s (si no está activo ni en recarga).
    if down and not _shield_latch and shield_time_left <= 0.0 and shield_cooldown <= 0.0:
        shield_charge += delta
        if shield_charge >= SHIELD_CHARGE_TIME:
            shield_charge = 0.0
            _shield_latch = true
            shield_time_left = SHIELD_DURATION
            shield_cooldown = SHIELD_DURATION + SHIELD_COOLDOWN
    else:
        shield_charge = 0.0


# --- Red --------------------------------------------------------------------

func snapshot() -> PackedFloat32Array:
    var a := PackedFloat32Array()
    for n in PART_ORDER:
        var rb: RigidBody2D = parts[n]
        a.append(rb.global_position.x)
        a.append(rb.global_position.y)
        a.append(rb.rotation)
    a.append(health)
    a.append(1.0 if shield_time_left > 0.0 else 0.0)
    a.append(jump_charge / JUMP_CHARGE_TIME)
    a.append(shield_charge / SHIELD_CHARGE_TIME)
    return a


func apply_snapshot(a: PackedFloat32Array) -> void:
    if a.size() != PART_ORDER.size() * 3 + 4:
        return  # validación de tamaño
    _targets = a
    var i := PART_ORDER.size() * 3
    health = clampf(a[i], 0.0, 100.0)
    shield_time_left = 1.0 if a[i + 1] > 0.5 else 0.0
    jump_charge = clampf(a[i + 2], 0.0, 1.0) * JUMP_CHARGE_TIME
    shield_charge = clampf(a[i + 3], 0.0, 1.0) * SHIELD_CHARGE_TIME


func _process(delta: float) -> void:
    if is_puppet and _targets.size() > 0:
        var w := 1.0 - exp(-delta * 18.0)  # interpolación suave hacia el último estado
        for i in PART_ORDER.size():
            var rb: RigidBody2D = parts[PART_ORDER[i]]
            rb.global_position = rb.global_position.lerp(Vector2(_targets[i * 3], _targets[i * 3 + 1]), w)
            rb.rotation = lerp_angle(rb.rotation, _targets[i * 3 + 2], w)
    queue_redraw()


func _draw() -> void:
    if parts.is_empty():
        return
    var head_pos: Vector2 = (parts["head"] as RigidBody2D).global_position
    var bar_pos := head_pos + Vector2(-26, -34)
    if jump_charge > 0.0:
        draw_rect(Rect2(bar_pos, Vector2(52, 7)), Color(0, 0, 0, 0.45))
        draw_rect(Rect2(bar_pos, Vector2(52.0 * jump_charge / JUMP_CHARGE_TIME, 7)), Color.WHITE)
    if shield_charge > 0.0:
        draw_rect(Rect2(bar_pos, Vector2(52, 7)), Color(0, 0, 0, 0.45))
        draw_rect(Rect2(bar_pos, Vector2(52.0 * shield_charge / SHIELD_CHARGE_TIME, 7)), Color("#2F8CFF"))
    if shield_time_left > 0.0:
        var c := torso_pos()
        draw_circle(c, 62.0, Color(0.3, 0.6, 1.0, 0.16))
        draw_arc(c, 62.0, 0.0, TAU, 48, Color(0.4, 0.75, 1.0, 0.9), 4.0, true)
