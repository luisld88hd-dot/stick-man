# Stickman Physics Arena

Juego Android 2D de stickmans con ragdoll físico (Godot 4.3, GDScript) y multijugador por Wi-Fi local (ENet/UDP).

## Estado real de esta versión (v0.1.0)

Implementado en código:
- Menú principal con los 6 botones; **JUGAR SOLO** y **MULTIJUGADOR** abren pantallas reales.
- Ragdoll de 11 `RigidBody2D` + `PinJoint2D`, equilibrio por torques PD y muelle de soporte.
- Golpe con reacción según la parte golpeada, aturdimiento/caída, eliminación por caer fuera de la arena.
- Salto especial (mantener arriba 2 s, barra blanca) y escudo (mantener abajo 2 s, barra azul, 3 s de duración, 5 s de recarga).
- Duelo contra IA básica, cajas físicas, plataformas.
- Multijugador LAN: crear sala, buscar por broadcast UDP, conectar por IP, anfitrión autoritativo, snapshots ~20/s con suavizado en el cliente.
- Flujo de GitHub Actions que compila un APK debug.

**No** implementado todavía (los botones muestran un aviso): personalización, arsenal, editor de arenas, configuración, audio, lobby completo.

**Sin probar:** no hay Godot en el entorno donde se generó, así que ni los scripts ni la física ni la red se han ejecutado. Es probable que haya que corregir errores y ajustar las constantes de equilibrio (`scripts/physics/fighter.gd`). El multijugador no se ha probado con dos teléfonos.

## Compilar el APK en GitHub

1. Crea un repositorio nuevo en github.com (vacío, sin README).
2. Sube el contenido de esta carpeta (la raíz del repo debe contener `project.godot`):
   ```bash
   git init
   git add .
   git commit -m "Primera versión"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/stickman-physics-arena.git
   git push -u origin main
   ```
   (Sin Git: en la web del repo, "Add file" → "Upload files" y arrastra todo, incluida la carpeta oculta `.github`.)
3. Entra en la pestaña **Actions**. El flujo "Build Android APK" arranca solo con cada push; también puedes lanzarlo con **Run workflow**.
4. Cuando termine (unos minutos), abre la ejecución y descarga el artefacto **stickman-physics-arena-apk** (viene en un ZIP con el `.apk` dentro).
5. Pasa el APK al teléfono y ábrelo (permite "instalar apps desconocidas"). Es un APK de depuración firmado con una clave debug generada en el flujo.

Si el flujo falla, copia el error de la pestaña Actions y corrígelo; los fallos más probables son errores de sintaxis GDScript o de configuración de exportación.

## Jugar entre dos teléfonos

1. Conecta ambos a la misma red Wi-Fi, o activa un punto de acceso en uno y conecta el otro.
2. Teléfono A: MULTIJUGADOR → CREAR PARTIDA (muestra IP y puerto 7777).
3. Teléfono B: MULTIJUGADOR → BUSCAR PARTIDAS LOCALES, o escribe la IP en CONECTAR POR IP.
4. Teléfono A: INICIAR PARTIDA.

Algunos hotspots aíslan los dispositivos entre sí y la búsqueda por broadcast puede fallar; en ese caso usa la IP manual o prueba otra red.
